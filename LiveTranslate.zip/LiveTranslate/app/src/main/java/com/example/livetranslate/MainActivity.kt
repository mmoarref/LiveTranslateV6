package com.example.livetranslate

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.util.Linkify
import android.view.View
import android.widget.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

data class Cfg(
    val asrId: String, val asrName: String, val asrKind: String,
    val asrBase: String, val asrKey: String, val asrModel: String,
    val chatId: String, val chatName: String,
    val chatBase: String, val chatKey: String, val chatModel: String
)

class MainActivity : Activity() {

    private val ui = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var out: TextView          // Persian translation
    private lateinit var scroll: ScrollView     // Persian scroll
    private lateinit var enView: TextView       // original (English) text
    private lateinit var enScroll: ScrollView
    private lateinit var status: TextView
    private lateinit var engine: TextView
    private lateinit var btn: Button
    private lateinit var levelBar: ProgressBar
    private lateinit var settings: LinearLayout
    private lateinit var asrList: LinearLayout
    private lateinit var chatList: LinearLayout
    private lateinit var provBox: LinearLayout
    private val edits = mutableMapOf<String, EditText>()
    private val enDone = StringBuilder()
    private var enPartial = ""
    private var running = false
    private var fontSize = 18f
    private var asrSel = "vosk"
    private var chatSel = "google"
    private var cfg: Cfg? = null

    private val prefs get() = getSharedPreferences("p", Context.MODE_PRIVATE)
    private fun isVosk(id: String) = id == "vosk" || id == "vosk-large"

    private fun field(hint: String, value: String, secret: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setText(value)
        textSize = 12f
        setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT or
            (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
    }

    private fun label(t: String, size: Float = 13f, color: Int = Color.LTGRAY, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 10, 0, 4)
        }

    private fun smallButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(32, 6, 32, 6)
        setOnClickListener { onClick() }
    }

    private fun sectionHeader(title: String, onCopy: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        setPadding(0, 6, 0, 2)
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 12f; setTextColor(Color.parseColor("#9FB0C0"))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        addView(smallButton("کپی", onCopy))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fontSize = prefs.getFloat("font", 18f)
        asrSel = prefs.getString("asr_sel", "vosk") ?: "vosk"
        chatSel = prefs.getString("chat_sel", "google") ?: "google"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(24, 48, 24, 24)
            setBackgroundColor(Color.parseColor("#101418"))
        }
        btn = Button(this).apply { text = START; setOnClickListener { toggle() } }
        val gear = Button(this).apply { text = "⚙"; setOnClickListener {
            settings.visibility = if (settings.visibility == View.GONE) View.VISIBLE else View.GONE
        } }
        val smaller = Button(this).apply { text = "A−"; setOnClickListener { setFont(fontSize - 2) } }
        val bigger = Button(this).apply { text = "A+"; setOnClickListener { setFont(fontSize + 2) } }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btn, LinearLayout.LayoutParams(0, -2, 1f))
            addView(gear); addView(smaller); addView(bigger)
        }

        asrList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        provBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val settingsInner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("۱) تشخیص صدای انگلیسی  (✓ = انتخاب‌شده)", 14f, Color.WHITE, true))
            addView(asrList)
            addView(label("۲) ترجمه به فارسی  (✓ = انتخاب‌شده)", 14f, Color.WHITE, true))
            addView(chatList)
            addView(label("کلید و مدل سرویس‌های انتخاب‌شده", 14f, Color.WHITE, true))
            addView(provBox)
        }
        settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(ScrollView(this@MainActivity).apply { addView(settingsInner) },
                LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.62).toInt()))
        }

        levelBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        status = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, 8, 0, 0) }
        engine = TextView(this).apply { setTextColor(Color.parseColor("#7BD88F")); textSize = 11f; setPadding(0, 2, 0, 4) }

        // top third: original text
        enView = TextView(this).apply {
            setTextColor(Color.parseColor("#9FB0C0")); textSize = 12f
            layoutDirection = View.LAYOUT_DIRECTION_LTR; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        enScroll = ScrollView(this).apply { addView(enView) }

        // bottom two thirds: Persian translation
        out = TextView(this).apply {
            setTextColor(Color.parseColor("#EDEDED")); textSize = fontSize; setLineSpacing(0f, 1.55f)
            layoutDirection = View.LAYOUT_DIRECTION_RTL; textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        }
        scroll = ScrollView(this).apply { addView(out) }

        root.addView(top)
        root.addView(settings)
        root.addView(levelBar)
        root.addView(status)
        root.addView(engine)
        root.addView(sectionHeader("متن اصلی (انگلیسی)") {
            copyText("متن اصلی", (enDone.toString() + enPartial).trim())
        })
        root.addView(enScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(sectionHeader("ترجمه‌ی فارسی") {
            copyText("ترجمه", out.text.toString().trim())
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 2f))
        setContentView(root)

        refresh()

        Bus.chunks.onEach { c ->
            val near = nearBottom(scroll)
            if (c.text.isNotEmpty()) out.append(c.text)
            out.append(if (c.endParagraph) "\n\n" else " ")
            if (near) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }.launchIn(ui)
        Bus.english.onEach { e ->
            if (e.final) {
                if (e.text.isNotEmpty()) enDone.append(e.text).append("\n")
                enPartial = ""
            } else enPartial = e.text
            renderEn()
        }.launchIn(ui)
        Bus.status.onEach { status.text = it }.launchIn(ui)
        Bus.engine.onEach { engine.text = it }.launchIn(ui)
        Bus.level.onEach { levelBar.progress = it }.launchIn(ui)
    }

    private fun nearBottom(sv: ScrollView): Boolean {
        val c = sv.getChildAt(0) ?: return true
        return c.bottom - (sv.height + sv.scrollY) < 250
    }

    private fun renderEn() {
        val near = nearBottom(enScroll)
        val s = SpannableStringBuilder(enDone)
        val st = s.length
        s.append(enPartial)
        s.setSpan(ForegroundColorSpan(Color.parseColor("#5F7080")), st, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        enView.text = s
        if (near) enScroll.post { enScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyText(label: String, text: String) {
        if (text.isEmpty()) { toast("متنی برای کپی وجود ندارد"); return }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("$label کپی شد")
    }

    // ---------- settings UI ----------

    private fun row(title: String, desc: String, on: Boolean, onClick: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(if (on) Color.parseColor("#1E2A22") else Color.TRANSPARENT)
            setOnClickListener {
                if (running) { toast("ابتدا توقف را بزنید"); return@setOnClickListener }
                onClick()
            }
        }
        r.addView(TextView(this).apply {
            text = (if (on) "✓  " else "○  ") + title
            setTextColor(if (on) Color.parseColor("#7BD88F") else Color.WHITE)
            textSize = 15f
        })
        r.addView(TextView(this).apply { text = desc; setTextColor(Color.GRAY); textSize = 11f })
        return r
    }

    private fun refresh() {
        saveFields()
        asrList.removeAllViews(); chatList.removeAllViews(); provBox.removeAllViews(); edits.clear()

        asrList.addView(row("Vosk کوچک — روی گوشی (بدون کلید)", "رایگان؛ سریع و سبک (دانلود حدود ۴۰ مگابایت)؛ دقت کمتر", asrSel == "vosk") { asrSel = "vosk"; persistSel() })
        asrList.addView(row("Vosk بزرگ — روی گوشی (بدون کلید)", "رایگان؛ کمی دقیق‌تر (دانلود حدود ۱۲۸ مگابایت، حافظه‌ی بیشتر)", asrSel == "vosk-large") { asrSel = "vosk-large"; persistSel() })
        for (p in Providers.all) if (p.asrModel != null)
            asrList.addView(row(p.name, "${p.asrModel.ifEmpty { "مدل دلخواه" }} — ${p.note}", asrSel == p.id) { asrSel = p.id; persistSel() })

        chatList.addView(row("مترجم گوگل (بدون کلید)", "رایگان و آنلاین؛ ترجمه‌ی ماشینی ساده", chatSel == "google") { chatSel = "google"; persistSel() })
        for (p in Providers.all) if (p.chatModel != null)
            chatList.addView(row(p.name, "${p.chatModel.ifEmpty { "مدل دلخواه" }} — ${p.note}", chatSel == p.id) { chatSel = p.id; persistSel() })

        val ids = listOf(asrSel, chatSel).filter { !isVosk(it) && it != "google" }.distinct()
        if (ids.isEmpty()) provBox.addView(label("موتور انتخاب‌شده کلید لازم ندارد.", 12f))
        else provBox.addView(label("اگر تشخیص با سرویس ابری خطا بدهد، برنامه موقتاً خودکار به Vosk می‌رود.", 11f, Color.GRAY))
        for (id in ids) provBox.addView(providerBlock(Providers.get(id)))

        if (!running) engine.text = idleText()
    }

    private fun persistSel() {
        prefs.edit().putString("asr_sel", asrSel).putString("chat_sel", chatSel).apply()
        refresh()
    }

    private fun providerBlock(p: Provider): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 8, 0, 12) }
        box.addView(label(p.name, 14f, Color.parseColor("#7BD88F"), true))
        if (p.keyUrl.isNotEmpty()) {
            box.addView(TextView(this).apply {
                text = "دریافت کلید: ${p.keyUrl}"
                textSize = 12f; setTextColor(Color.LTGRAY); setLinkTextColor(Color.parseColor("#7FB7FF"))
                Linkify.addLinks(this, Linkify.WEB_URLS)
            })
        }
        fun add(key: String, hint: String, def: String, secret: Boolean = false) {
            val saved = prefs.getString(key, null)
                ?: if (key.startsWith("k_")) prefs.getString("key_" + key.removePrefix("k_"), null) else null
            val e = field(hint, saved ?: def, secret)
            edits[key] = e; box.addView(e)
        }
        add("k_${p.id}", "کلید API — ${p.name}", "", secret = true)
        if (p.id == "custom") add("b_custom", "آدرس سرویس (Base URL)، مثلاً https://…/v1", "")
        if (asrSel == p.id) add("am_${p.id}", "مدل تشخیص صدا", p.asrModel ?: "")
        if (chatSel == p.id) add("cm_${p.id}", "مدل ترجمه", p.chatModel ?: "")
        return box
    }

    private fun saveFields() {
        if (edits.isEmpty()) return
        val e = prefs.edit()
        for ((k, v) in edits) e.putString(k, v.text.toString().trim())
        e.apply()
    }

    private fun asrLabel(): String = when (asrSel) {
        "vosk" -> "Vosk کوچک (روی گوشی)"
        "vosk-large" -> "Vosk بزرگ (روی گوشی)"
        else -> Providers.get(asrSel).name
    }
    private fun chatLabel(): String =
        if (chatSel == "google") "مترجم گوگل" else Providers.get(chatSel).name
    private fun idleText() = "انتخاب‌شده — تشخیص: ${asrLabel()}  •  ترجمه: ${chatLabel()}"

    private fun v(key: String, def: String) = edits[key]?.text?.toString()?.trim() ?: def

    private fun buildCfg(): Cfg? {
        var aName = ""; var aKind = ""; var aBase = ""; var aKey = ""; var aModel = ""
        var cName = ""; var cBase = ""; var cKey = ""; var cModel = ""
        if (!isVosk(asrSel)) {
            val p = Providers.get(asrSel)
            aName = p.name; aKind = p.asrKind
            aKey = v("k_${p.id}", ""); aBase = if (p.id == "custom") v("b_custom", "") else p.base
            aModel = v("am_${p.id}", p.asrModel ?: "")
            if (aKey.isEmpty()) { toast("کلید API ${p.name} را وارد کنید (برای تشخیص صدا)"); return null }
            if (aBase.isEmpty() || aModel.isEmpty()) { toast("آدرس و مدل تشخیص صدا را کامل وارد کنید"); return null }
        }
        if (chatSel != "google") {
            val p = Providers.get(chatSel)
            cName = p.name
            cKey = v("k_${p.id}", ""); cBase = if (p.id == "custom") v("b_custom", "") else p.base
            cModel = v("cm_${p.id}", p.chatModel ?: "")
            if (cKey.isEmpty()) { toast("کلید API ${p.name} را وارد کنید (برای ترجمه)"); return null }
            if (cBase.isEmpty() || cModel.isEmpty()) { toast("آدرس و مدل ترجمه را کامل وارد کنید"); return null }
        }
        return Cfg(asrSel, aName, aKind, aBase, aKey, aModel, chatSel, cName, cBase, cKey, cModel)
    }

    // ---------- start / stop ----------

    private fun setFont(size: Float) {
        fontSize = size.coerceIn(12f, 34f)
        out.textSize = fontSize
        prefs.edit().putFloat("font", fontSize).apply()
    }

    private fun toggle() {
        if (running) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            running = false; btn.text = START; levelBar.progress = 0; refresh(); return
        }
        val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        saveFields()
        cfg = buildCfg() ?: return
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) toggle()
        else toast("دسترسی میکروفون لازم است (برای ضبط صدای داخلی)")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val c = cfg
        if (rc == 2 && res == RESULT_OK && data != null && c != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", res).putExtra("data", data)
                .putExtra("asrId", c.asrId).putExtra("asrName", c.asrName).putExtra("asrKind", c.asrKind)
                .putExtra("asrBase", c.asrBase).putExtra("asrKey", c.asrKey).putExtra("asrModel", c.asrModel)
                .putExtra("chatId", c.chatId).putExtra("chatName", c.chatName)
                .putExtra("chatBase", c.chatBase).putExtra("chatKey", c.chatKey).putExtra("chatModel", c.chatModel)
            startForegroundService(i)
            running = true; btn.text = "توقف"
            out.text = ""; enDone.setLength(0); enPartial = ""; renderEn()
            engine.text = idleText()
            settings.visibility = View.GONE
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { ui.cancel(); super.onDestroy() }

    companion object { const val START = "شروع ترجمه زنده (انگلیسی ← فارسی)" }
}
