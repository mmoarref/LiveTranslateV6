package com.example.livetranslate

/**
 * asrKind:
 *  "whisper"       -> POST {base}/audio/transcriptions (OpenAI style, with prompt/temperature)
 *  "whisper-basic" -> same endpoint, only model/file/language (Mistral Voxtral)
 *  "chat-audio"    -> POST {base}/chat/completions with input_audio (Gemini)
 */
data class Provider(
    val id: String,
    val name: String,
    val base: String,
    val asrModel: String?,   // null = no speech recognition
    val asrKind: String,
    val chatModel: String?,  // null = no translation
    val keyUrl: String,
    val note: String
)

object Providers {
    val all = listOf(
        Provider("groq", "Groq", "https://api.groq.com/openai/v1",
            "whisper-large-v3-turbo", "whisper", "llama-3.3-70b-versatile",
            "https://console.groq.com/keys", "رایگان، بدون کارت بانکی"),
        Provider("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai",
            "gemini-2.5-flash", "chat-audio", "gemini-2.5-flash",
            "https://aistudio.google.com/apikey", "سهمیه‌ی رایگان — اگر نام مدل قدیمی شد، در کادر مدل عوض کنید"),
        Provider("mistral", "Mistral", "https://api.mistral.ai/v1",
            "voxtral-mini-latest", "whisper-basic", "mistral-small-latest",
            "https://console.mistral.ai/api-keys", "سطح رایگان دارد"),
        Provider("cerebras", "Cerebras", "https://api.cerebras.ai/v1",
            null, "whisper", "gpt-oss-120b",
            "https://cloud.cerebras.ai", "فقط ترجمه — سطح رایگان (محدودیت‌ها متغیر است)"),
        Provider("openrouter", "OpenRouter", "https://openrouter.ai/api/v1",
            "openai/whisper-large-v3", "whisper", "meta-llama/llama-3.3-70b-instruct:free",
            "https://openrouter.ai/keys", "مدل ترجمه‌ی رایگان (:free) دارد؛ تشخیص صدایش پولی است"),
        Provider("openai", "OpenAI", "https://api.openai.com/v1",
            "gpt-4o-mini-transcribe", "whisper", "gpt-4o-mini",
            "https://platform.openai.com/api-keys", "پولی"),
        Provider("custom", "سفارشی", "",
            "", "whisper", "",
            "", "هر سرویس سازگار با OpenAI — آدرس و مدل‌ها را خودتان وارد کنید")
    )

    fun get(id: String) = all.first { it.id == id }
}
