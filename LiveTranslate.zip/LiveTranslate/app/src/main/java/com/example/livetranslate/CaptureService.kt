package com.example.livetranslate

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.flow.MutableSharedFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import kotlin.math.sqrt

data class Chunk(val text: String, val endParagraph: Boolean)
data class En(val text: String, val final: Boolean)

object Bus {
    val chunks = MutableSharedFlow<Chunk>(extraBufferCapacity = 128) // stable Persian text, append-only
    val english = MutableSharedFlow<En>(extraBufferCapacity = 128)   // original text (partial / final)
    val status = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val engine = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val level = MutableSharedFlow<Int>(extraBufferCapacity = 16)
}

/**
 * Recognition: Vosk (small or large, on phone)  OR  cloud ASR (Whisper-style / Gemini audio chat).
 * If cloud ASR keeps failing the service switches to Vosk automatically and retries the cloud later.
 * Translation: Google Translate (keyless) OR an OpenAI-compatible LLM, with automatic fallbacks.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "stop"
        const val SR = 16000

        // key -> (folder/zip name, size in MB)
        val MODELS = mapOf(
            "small" to Pair("vosk-model-small-en-us-0.15", 40),
            "large" to Pair("vosk-model-en-us-0.22-lgraph", 128)
        )

        const val HOLD = 3
        const val MIN_CHUNK = 6
        const val MAX_CHUNK = 10
        val BREAKERS = setOf(
            "and", "but", "so", "because", "which", "that", "who", "while", "when",
            "if", "as", "then", "or", "after", "before", "although", "where", "however"
        )
    }

    class ApiError(val code: Int) : Exception("HTTP $code")

    private class Seg {
        val buf = ByteArrayOutputStream()
        var ms = 0
        var silence = 0
        var speech = 0
        var prev: ByteArray? = null
        fun reset() { buf.reset(); ms = 0; silence = 0; speech = 0; prev = null }
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private val queue = LinkedBlockingQueue<ByteArray>(300)
    private val work = LinkedBlockingQueue<ByteArray>()

    // configuration
    private var asrApi = false
    private var voskKey = "small"
    private var asrKind = ""
    private var asrName = ""
    private var asrBase = ""
    private var asrKey = ""
    private var asrModel = ""
    private var llm = false
    private var chatName = ""
    private var chatBase = ""
    private var chatKey = ""
    private var chatModel = ""

    // Vosk
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var lastPartial = ""
    private var voskBroken = false

    // ASR fallback state
    @Volatile private var fallbackActive = false
    @Volatile private var asrFailStreak = 0
    @Volatile private var cloudRetryAt = 0L
    @Volatile private var asrLabel = ""
    private var cloudLabel = ""

    private var translator: Translator? = null
    @Volatile private var offlineOk = false
    private val tx = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var gtxFails = 0
    private var gtxBlockedUntil = 0L
    private var llmFails = 0
    private var llmBlockedUntil = 0L
    @Volatile private var errShown = false
    @Volatile private var lastEngine = ""
    @Volatile private var lastTranslation = ""
    @Volatile private var prevEnglish = ""
    @Volatile private var prevPersian = ""
    private var committedWords = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startForegroundNotification()
        val code = intent.getIntExtra("code", 0)
        val data: Intent? = intent.getParcelableExtra("data", Intent::class.java)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        fun s(k: String) = intent.getStringExtra(k)?.trim() ?: ""
        val asrId = s("asrId")
        asrApi = asrId != "vosk" && asrId != "vosk-large"
        voskKey = if (asrId == "vosk-large") "large" else "small"
        asrKind = s("asrKind"); asrName = s("asrName")
        asrBase = s("asrBase").trimEnd('/'); asrKey = s("asrKey"); asrModel = s("asrModel")
        llm = s("chatId") != "google"
        chatName = s("chatName")
        chatBase = s("chatBase").trimEnd('/'); chatKey = s("chatKey"); chatModel = s("chatModel")

        cloudLabel = "$asrModel ($asrName)"
        asrLabel = if (asrApi) cloudLabel else voskLabel(voskKey)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)

        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.PERSIAN)
                .build()
        )
        running = true
        Thread { runAll() }.start()
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "Capture", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "cap")
            .setContentTitle("ترجمه زنده فعال است")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "توقف", stopPi).build())
            .build()
        startForeground(
            1, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    // ---------------- labels / errors ----------------

    private fun voskLabel(key: String) = if (key == "large") "Vosk بزرگ (روی گوشی)" else "Vosk (روی گوشی)"

    private fun setEngine(translation: String) {
        lastTranslation = translation
        val label = "تشخیص: $asrLabel  •  ترجمه: $translation"
        if (label != lastEngine) { lastEngine = label; Bus.engine.tryEmit(label) }
    }

    private fun initialTranslatorLabel() = if (llm) "$chatModel ($chatName)" else "مترجم گوگل (آنلاین)"

    private fun showError(msg: String) { errShown = true; Bus.status.tryEmit(msg) }
    private fun clearError() {
        if (errShown) { errShown = false; Bus.status.tryEmit("در حال گوش دادن… صوت انگلیسی را پخش کنید") }
    }

    private fun apiErrorText(code: Int) = when (code) {
        401 -> "کلید API نامعتبر است"
        403, 404 -> "دسترسی ممکن نیست (آدرس/مدل اشتباه یا محدودیت منطقه‌ای؛ VPN را بررسی کنید)"
        429 -> "سقف درخواست یا سهمیه‌ی رایگان پر شده"
        else -> "خطای سرویس (کد $code)"
    }

    // ---------------- worker ----------------

    private fun runAll() {
        try {
            if (!asrApi) {
                if (!loadVosk(voskKey)) return
                Bus.status.tryEmit("آماده‌سازی مدل ترجمه آفلاین (جایگزین؛ بار اول دانلود می‌شود)…")
                try {
                    Tasks.await(translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build()))
                    offlineOk = true
                } catch (e: Exception) { offlineOk = false }
                if (!running) return
            }
            startCapture()
            setEngine(initialTranslatorLabel())
            Bus.status.tryEmit("در حال گوش دادن… صوت انگلیسی را پخش کنید")
            if (asrApi) Thread { segmentWorker() }.start()
            mainLoop()
        } catch (e: Exception) {
            showError("خطا: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            try { rec?.close() } catch (_: Exception) {}
            try { model?.close() } catch (_: Exception) {}
        }
    }

    // ---------- Vosk loading ----------

    private fun loadVosk(key: String): Boolean {
        val (name, mb) = MODELS.getValue(key)
        val dir = File(filesDir, name)
        if (!File(dir, "am/final.mdl").exists()) downloadModel(name, mb)
        if (!running) return false
        if (!File(dir, "am/final.mdl").exists()) return false
        Bus.status.tryEmit("در حال بارگذاری مدل تشخیص گفتار…")
        val m = Model(dir.absolutePath)
        model = m
        rec = Recognizer(m, SR.toFloat())
        return true
    }

    /** Called when the cloud recognizer failed: prepare Vosk (the large one if it is already on the phone). */
    private fun ensureFallbackVosk(): Boolean {
        if (voskBroken) return false
        val largeReady = File(filesDir, MODELS.getValue("large").first + "/am/final.mdl").exists()
        val key = if (largeReady) "large" else "small"
        return try {
            Bus.status.tryEmit("تشخیص با $asrName ناموفق بود؛ آماده‌سازی Vosk…")
            val ok = loadVosk(key)
            if (!ok) voskBroken = true
            ok
        } catch (e: Exception) {
            voskBroken = true
            showError("مدل Vosk هم در دسترس نیست: ${e.message ?: e.javaClass.simpleName}")
            false
        }
    }

    private fun downloadModel(name: String, mb: Int) {
        Bus.status.tryEmit("دانلود مدل تشخیص گفتار (حدود $mb مگابایت)…")
        val zip = File(cacheDir, "model.zip")
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        val total = conn.contentLengthLong
        conn.inputStream.use { ins ->
            FileOutputStream(zip).use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var lastPct = -1
                while (running) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != lastPct) { lastPct = pct; Bus.status.tryEmit("دانلود مدل تشخیص گفتار: $pct٪") }
                    }
                }
            }
        }
        if (!running) return
        Bus.status.tryEmit("در حال استخراج مدل…")
        val tmp = File(filesDir, "model_tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        ZipInputStream(FileInputStream(zip)).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val f = File(tmp, e.name)
                if (!f.canonicalPath.startsWith(tmp.canonicalPath)) error("zip نامعتبر")
                if (e.isDirectory) f.mkdirs()
                else { f.parentFile?.mkdirs(); FileOutputStream(f).use { zis.copyTo(it) } }
                e = zis.nextEntry
            }
        }
        zip.delete()
        val target = File(filesDir, name)
        target.deleteRecursively()
        File(tmp, name).renameTo(target)
        tmp.deleteRecursively()
    }

    // ---------- capture ----------

    @Suppress("MissingPermission")
    private fun startCapture() {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(minBuf * 4)
            .setAudioPlaybackCaptureConfig(cfg)
            .build()
        record = ar
        ar.startRecording()

        Thread {
            val frame = ShortArray(SR / 10)
            var silentMs = 0
            var warned = false
            var tick = 0
            while (running) {
                val n = ar.read(frame, 0, frame.size)
                if (n <= 0) continue
                val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                var sum = 0.0
                var peak = 0
                for (i in 0 until n) {
                    val s = frame[i].toInt()
                    bb.putShort(frame[i])
                    sum += s.toDouble() * s
                    val a = if (s < 0) -s else s
                    if (a > peak) peak = a
                }
                val bytes = bb.array()
                if (!queue.offer(bytes)) { queue.poll(); queue.offer(bytes) }

                if (++tick % 3 == 0) Bus.level.tryEmit(minOf(100, (sqrt(sum / n) / 40).toInt()))
                if (peak == 0) {
                    silentMs += 100
                    if (silentMs >= 5000 && !warned) {
                        warned = true
                        Bus.status.tryEmit("هیچ صدایی از دستگاه دریافت نمی‌شود. صوت را پخش کنید (بعضی برنامه‌ها ضبط صدایشان را مسدود کرده‌اند).")
                    }
                } else {
                    silentMs = 0
                    if (warned) { warned = false; Bus.status.tryEmit("در حال گوش دادن… صوت انگلیسی را پخش کنید") }
                }
            }
        }.start()
    }

    // ---------- main audio loop (Vosk or cloud, with automatic fallback) ----------

    private fun mainLoop() {
        val seg = Seg()
        while (running) {
            val chunk = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue

            // time to try the cloud recognizer again
            if (asrApi && fallbackActive && System.currentTimeMillis() > cloudRetryAt) {
                flushVosk()
                fallbackActive = false
                asrFailStreak = 0
                asrLabel = cloudLabel
                setEngine(lastTranslation)
                seg.reset()
            }

            var useVosk = !asrApi || fallbackActive
            if (useVosk && rec == null) {
                if (!ensureFallbackVosk()) {
                    fallbackActive = false
                    asrLabel = cloudLabel
                    setEngine(lastTranslation)
                    useVosk = false
                }
            }
            if (useVosk) feedVosk(chunk) else feedSegmenter(seg, chunk)
        }
    }

    private fun feedVosk(chunk: ByteArray) {
        val r = rec ?: return
        if (r.acceptWaveForm(chunk, chunk.size)) {
            val t = JSONObject(r.result).optString("text").trim()
            lastPartial = ""
            main.post { onFinal(t) }
        } else {
            val p = JSONObject(r.partialResult).optString("partial").trim()
            if (p.isNotEmpty() && p != lastPartial) {
                lastPartial = p
                main.post { onPartial(p) }
            }
        }
    }

    private fun flushVosk() {
        val r = rec ?: return
        try {
            val t = JSONObject(r.finalResult).optString("text").trim()
            lastPartial = ""
            main.post { onFinal(t) }
        } catch (_: Exception) {}
    }

    private fun feedSegmenter(seg: Seg, chunk: ByteArray) {
        val loud = rmsOf(chunk) > 250
        if (seg.buf.size() == 0) {
            if (!loud) { seg.prev = chunk; return }
            seg.prev?.let { seg.buf.write(it); seg.ms += 100 }
        }
        if (loud) { seg.speech += 100; seg.silence = 0 } else seg.silence += 100
        seg.buf.write(chunk); seg.ms += 100

        val endOfPhrase = seg.ms >= 2500 && seg.silence >= 400
        if (endOfPhrase || seg.ms >= 9000) {
            if (seg.speech >= 600) work.offer(seg.buf.toByteArray())
            seg.reset()
        }
    }

    private fun rmsOf(b: ByteArray): Double {
        val n = b.size / 2
        if (n == 0) return 0.0
        var sum = 0.0
        for (i in 0 until n) {
            val v = ((b[2 * i + 1].toInt() shl 8) or (b[2 * i].toInt() and 0xFF)).toShort().toInt()
            sum += v.toDouble() * v
        }
        return sqrt(sum / n)
    }

    // ---------- cloud ASR ----------

    private fun segmentWorker() {
        while (running) {
            val s = work.poll(200, TimeUnit.MILLISECONDS) ?: continue
            try { processSegment(s) } catch (e: ApiError) {
                asrFailed("$asrName: ${apiErrorText(e.code)}")
            } catch (e: Exception) {
                asrFailed("خطای شبکه ($asrName): ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun asrFailed(msg: String) {
        showError(msg)
        if (++asrFailStreak >= 2 && !fallbackActive && !voskBroken) {
            fallbackActive = true
            cloudRetryAt = System.currentTimeMillis() + 60_000
            asrLabel = "Vosk (جایگزین)"
            setEngine(lastTranslation)
            showError("تشخیص با $asrName ناموفق بود؛ موقتاً Vosk فعال شد (هر ۶۰ ثانیه دوباره امتحان می‌شود)")
        }
    }

    private fun processSegment(pcm: ByteArray) {
        val text = transcribe(pcm)
        asrFailStreak = 0
        clearError()
        if (text.isEmpty() || isHallucination(text)) return
        Bus.english.tryEmit(En(text, true))
        val fa = translateAny(text)
        if (fa == null) prevEnglish = text
        Bus.chunks.tryEmit(Chunk(fa ?: "[ترجمه ناموفق]", true))
    }

    private fun isHallucination(t: String): Boolean {
        val n = t.lowercase().filter { it.isLetter() || it == ' ' }.trim()
        return n.length < 3 || n in setOf("you", "thank you", "thanks for watching", "bye", "thanks", "okay", "so")
    }

    private fun transcribe(pcm: ByteArray): String =
        if (asrKind == "chat-audio") transcribeViaChat(pcm) else transcribeWhisper(pcm, asrKind != "whisper-basic")

    private fun transcribeWhisper(pcm: ByteArray, extras: Boolean): String {
        val mb = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("model", asrModel)
            .addFormDataPart("language", "en")
        if (extras) {
            mb.addFormDataPart("response_format", "json").addFormDataPart("temperature", "0")
            if (prevEnglish.isNotEmpty()) mb.addFormDataPart("prompt", prevEnglish.takeLast(200))
        }
        mb.addFormDataPart("file", "a.wav", wavOf(pcm).toRequestBody("audio/wav".toMediaType()))
        val req = Request.Builder()
            .url("$asrBase/audio/transcriptions")
            .header("Authorization", "Bearer $asrKey")
            .post(mb.build()).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiError(r.code)
            return JSONObject(r.body!!.string()).optString("text").trim()
        }
    }

    /** Gemini (OpenAI-compatible endpoint): audio is sent inside a chat message. */
    private fun transcribeViaChat(pcm: ByteArray): String {
        val b64 = Base64.encodeToString(wavOf(pcm), Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text",
                "Transcribe this English speech exactly as spoken. Output only the transcript text, nothing else. If there is no clear speech, output nothing."))
            .put(JSONObject().put("type", "input_audio").put("input_audio",
                JSONObject().put("data", b64).put("format", "wav")))
        val payload = JSONObject()
            .put("model", asrModel)
            .put("temperature", 0)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val req = Request.Builder()
            .url("$asrBase/chat/completions")
            .header("Authorization", "Bearer $asrKey")
            .post(payload.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiError(r.code)
            return JSONObject(r.body!!.string()).getJSONArray("choices")
                .getJSONObject(0).getJSONObject("message").optString("content").trim()
        }
    }

    private fun wavOf(pcm: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
        h.putInt(SR).putInt(SR * 2).putShort(2).putShort(16)
        h.put("data".toByteArray()).putInt(pcm.size)
        return h.array() + pcm
    }

    // ---------- Vosk: stable chunking (main thread) ----------

    private fun words(s: String) = s.split(" ").filter { it.isNotEmpty() }

    private fun onPartial(p: String) {
        Bus.english.tryEmit(En(p, false))
        val w = words(p)
        val stable = w.size - HOLD
        if (stable - committedWords < MIN_CHUNK) return
        var cut = -1
        for (i in stable downTo committedWords + MIN_CHUNK - 1) {
            if (w[i].lowercase() in BREAKERS) { cut = i; break }
        }
        if (cut == -1) {
            if (stable - committedWords >= MAX_CHUNK) cut = stable else return
        }
        val text = w.subList(committedWords, cut).joinToString(" ")
        committedWords = cut
        translateAsync(text, false)
    }

    private fun onFinal(t: String) {
        if (t.isNotEmpty()) Bus.english.tryEmit(En(t, true))
        val w = words(t)
        val rest = if (committedWords < w.size) w.subList(committedWords, w.size).joinToString(" ") else ""
        committedWords = 0
        if (rest.isNotEmpty()) translateAsync(rest, true)
        else if (t.isNotEmpty()) Bus.chunks.tryEmit(Chunk("", true))
    }

    private fun translateAsync(text: String, endPara: Boolean) {
        tx.execute {
            val out = translateAny(text)
            Bus.chunks.tryEmit(Chunk(out ?: "[ترجمه ناموفق]", endPara))
        }
    }

    // ---------- translation with fallbacks ----------

    private fun remember(en: String, fa: String) { prevEnglish = en; prevPersian = fa }

    private fun translateAny(text: String): String? {
        if (llm && System.currentTimeMillis() > llmBlockedUntil) {
            var r: String? = null
            try { r = translateWithLlm(text); llmFails = 0 } catch (e: Exception) {
                llmFails++
                showError(
                    if (e is ApiError) "ترجمه با $chatName ناموفق: ${apiErrorText(e.code)} — از مترجم گوگل استفاده می‌شود"
                    else "ترجمه با $chatName ناموفق (شبکه) — از مترجم گوگل استفاده می‌شود"
                )
                if (llmFails >= 2) { llmBlockedUntil = System.currentTimeMillis() + 30000; llmFails = 0 }
            }
            if (r != null) {
                setEngine("$chatModel ($chatName)"); clearError(); remember(text, r); return r
            }
        }
        if (System.currentTimeMillis() > gtxBlockedUntil) {
            val g = try { googleTranslate(text) } catch (e: Exception) { null }
            if (g != null) {
                gtxFails = 0
                setEngine(if (llm) "مترجم گوگل (جایگزین)" else "مترجم گوگل (آنلاین)")
                remember(text, g); return g
            }
            if (++gtxFails >= 2) { gtxBlockedUntil = System.currentTimeMillis() + 30000; gtxFails = 0 }
        }
        if (offlineOk) {
            val m = try { translator?.let { Tasks.await(it.translate(text)) } } catch (e: Exception) { null }
            if (m != null) { setEngine("ML Kit (آفلاین، کیفیت کمتر)"); remember(text, m); return m }
        }
        return null
    }

    private fun translateWithLlm(text: String): String? {
        val system = "You are a professional English-to-Persian (Farsi) news interpreter. " +
            "Translate the given speech-transcript segment into fluent, natural, formal Persian as used by Iranian news media. " +
            "The segment may start or end in the middle of a sentence: translate it so it reads smoothly as a continuation of the previous text. " +
            "Silently fix obvious speech-recognition mistakes using context. Keep names, numbers and places accurate. " +
            "Output ONLY the Persian translation: no notes, no quotation marks, no English."
        val user = buildString {
            if (prevEnglish.isNotEmpty()) {
                append("Previous segment (context only, do not translate):\n").append(prevEnglish)
                append("\n\nIts Persian translation:\n").append(prevPersian).append("\n\n")
            }
            append("Segment to translate:\n").append(text)
        }
        val payload = JSONObject()
            .put("model", chatModel)
            .put("temperature", 0.2)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
        val req = Request.Builder()
            .url("$chatBase/chat/completions")
            .header("Authorization", "Bearer $chatKey")
            .post(payload.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw ApiError(r.code)
            var c = JSONObject(r.body!!.string()).getJSONArray("choices")
                .getJSONObject(0).getJSONObject("message").optString("content")
            c = c.replace(Regex("<think>[\\s\\S]*?</think>"), "").trim().trim('"', '«', '»')
            return c.takeIf { it.isNotEmpty() }
        }
    }

    /** Unofficial public Google Translate endpoint; may be rate-limited or change without notice. */
    private fun googleTranslate(text: String): String? {
        val u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=fa&dt=t&q=" +
            URLEncoder.encode(text, "UTF-8")
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 5000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode != 200) return null
        val body = c.inputStream.bufferedReader().use { it.readText() }
        val arr = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).optString(0))
        return sb.toString().trim().takeIf { it.isNotEmpty() }
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { record?.stop(); record?.release() } catch (_: Exception) {}
        projection?.stop()
        tx.shutdownNow()
        translator?.close(); translator = null
        Bus.status.tryEmit("متوقف شد")
        super.onDestroy()
    }
}
